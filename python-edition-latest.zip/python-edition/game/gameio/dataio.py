import json

class DataIO:
    def __init__(self) -> None:
        self.palette = self.retrievePalette()
    def retrievePalette(self): 
        with open("game/gameio/json/palette.json", "r") as paletteFile: return json.loads(paletteFile.read())