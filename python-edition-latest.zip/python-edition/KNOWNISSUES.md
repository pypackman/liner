# known issues

* inability to quit via the actual game, you have to quit the launcher to quit the game